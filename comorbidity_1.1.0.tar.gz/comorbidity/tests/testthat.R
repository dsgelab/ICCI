library(testthat)
library(comorbidity)

test_check("comorbidity")
